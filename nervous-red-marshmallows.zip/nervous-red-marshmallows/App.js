import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
  ScrollView,
  Platform,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';

// --- Ícones Simples (Emojis) ---
const binIcons = {
  papel: '📰',
  plastico: '🧴',
  vidro: '🍾',
  metal: '🥫',
  organico: '🍎',
  eletronico: '🔋',
  perigoso: '☣️',
  nao_reciclavel: '🗑️',
};

// --- Base de Dados Fictícia (com imageKeywords) ---
const wasteData = {
  'embalagem de iogurte': {
    type: 'plastico',
    name: 'Plástico (Embalagem de Iogurte)',
    instructions:
      'Lave para remover resíduos orgânicos. Descarte no cesto de PLÁSTICOS.',
    impact:
      'Reciclar plástico economiza recursos naturais e energia, além de reduzir o lixo em aterros.',
    imageKeywords: ['iogurte', 'yogurt', 'embalagem', 'pote', 'lácteo', 'plástico'],
  },
  'garrafa pet': {
    type: 'plastico',
    name: 'Plástico (Garrafa PET)',
    instructions: 'Esvazie e amasse. Descarte no cesto de PLÁSTICOS.',
    impact:
      'A reciclagem de PET reduz a poluição e a necessidade de extrair mais petróleo.',
    imageKeywords: ['garrafa', 'pet', 'refrigerante', 'água', 'plástico', 'transparente'],
  },
  'lata de refrigerante': {
    type: 'metal',
    name: 'Metal (Lata de Refrigerante)',
    instructions: 'Amasse para reduzir o volume. Descarte no cesto de METAIS.',
    impact:
      'Reciclar alumínio economiza até 95% da energia necessária para produzir o metal do zero.',
    imageKeywords: ['lata', 'alumínio', 'refrigerante', 'cerveja', 'metal', 'bebida'],
  },
  'papel de escritório': {
    type: 'papel',
    name: 'Papel (Papel de Escritório)',
    instructions:
      'Não amasse, apenas dobre se necessário. Descarte no cesto de PAPEL.',
    impact:
      'Reciclar papel poupa árvores, água e energia, além de reduzir a poluição do ar.',
    imageKeywords: ['papel', 'folha', 'documento', 'escritório', 'sulfite'],
  },
  'casca de banana': {
    type: 'organico',
    name: 'Orgânico (Casca de Banana)',
    instructions:
      'Descarte no cesto de ORGÂNICOS para compostagem, se disponível.',
    impact:
      'A compostagem de resíduos orgânicos reduz o metano nos aterros e cria adubo rico.',
    imageKeywords: ['banana', 'casca', 'fruta', 'orgânico', 'alimento'],
  },
  'pilha comum': {
    type: 'perigoso',
    name: 'Lixo Perigoso/Eletrônico (Pilha)',
    instructions:
      'NÃO descarte no lixo comum nem reciclável. Procure pontos de coleta específicos para pilhas e baterias.',
    impact:
      'Pilhas contêm metais pesados que contaminam o solo e a água se descartadas incorretamente.',
    imageKeywords: ['pilha', 'bateria', 'aa', 'aaa', 'energia', 'perigoso'],
  },
  'celular quebrado': {
    type: 'eletronico',
    name: 'Lixo Eletrônico (Celular)',
    instructions:
      'NÃO descarte no lixo comum. Procure pontos de coleta de lixo eletrônico ou programas de reciclagem do fabricante.',
    impact:
      'O lixo eletrônico contém materiais valiosos e substâncias tóxicas. A reciclagem adequada é crucial.',
    imageKeywords: ['celular', 'smartphone', 'telefone', 'quebrado', 'eletrônico', 'tela'],
  },
  'caixa de papelão': {
    type: 'papel',
    name: 'Papel (Caixa de Papelão)',
    instructions: 'Desmonte a caixa para reduzir o volume. Descarte no cesto de PAPEL.',
    impact: 'Reciclar papelão economiza árvores e reduz o volume de lixo em aterros.',
    imageKeywords: ['caixa', 'papelão', 'embalagem', 'ondulado', 'marrom'],
  },
  'copo de vidro': {
    type: 'vidro',
    name: 'Vidro (Copo)',
    instructions: 'Descarte com cuidado para evitar quebras. Se quebrado, embale em jornal. Descarte no cesto de VIDRO.',
    impact: 'O vidro é 100% reciclável e pode ser reciclado infinitas vezes sem perder qualidade.',
    imageKeywords: ['copo', 'vidro', 'taça', 'transparente', 'bebida'],
  }
};

// --- Componente Principal do App ---
export default function App() {
  const [itemName, setItemName] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [result, setResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const galleryStatus =
          await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (galleryStatus.status !== 'granted') {
          Alert.alert(
            'Permissão Necessária',
            'Desculpe, precisamos de permissão para acessar sua galeria de fotos.'
          );
        }
        const cameraStatus = await ImagePicker.requestCameraPermissionsAsync();
        if (cameraStatus.status !== 'granted') {
          Alert.alert(
            'Permissão Necessária',
            'Desculpe, precisamos de permissão para acessar sua câmera.'
          );
        }
      }
    })();
  }, []);

  const pickImageAsync = async () => {
    setResult(null);
    setItemName(''); // Limpa o nome do item se estiver usando imagem
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
      // *** MODIFICADO: Chama a simulação de análise de imagem ***
      simulateImageAnalysisWithTags(result.assets[0].uri);
    } else {
      setSelectedImage(null);
    }
  };

  const takePhotoAsync = async () => {
    setResult(null);
    setItemName(''); // Limpa o nome do item se estiver usando imagem
    let result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
      // *** MODIFICADO: Chama a simulação de análise de imagem ***
      simulateImageAnalysisWithTags(result.assets[0].uri);
    } else {
      setSelectedImage(null);
    }
  };

  // *** NOVA FUNÇÃO: Encontra o item na base de dados com base nas tags ***
  const findItemByTags = (tags) => {
    if (!tags || tags.length === 0) return null;

    let bestMatch = null;
    let maxMatches = 0;

    for (const key in wasteData) {
      const item = wasteData[key];
      let currentMatches = 0;
      if (item.imageKeywords) {
        tags.forEach(tag => {
          if (item.imageKeywords.includes(tag.toLowerCase())) {
            currentMatches++;
          }
        });
      }
      // Verifica também se alguma tag corresponde ao nome do item (chave)
      tags.forEach(tag => {
        if (key.includes(tag.toLowerCase())) {
            currentMatches++;
        }
      });


      if (currentMatches > maxMatches) {
        maxMatches = currentMatches;
        bestMatch = item;
      }
    }
    // Consideramos um match válido se houver pelo menos uma correspondência significativa.
    // Você pode ajustar esse limiar (ex: `maxMatches > 1`).
    return maxMatches > 0 ? bestMatch : null;
  };


  // *** MODIFICADA: Função para simular a análise da imagem e retorno de TAGS ***
  const simulateImageAnalysisWithTags = (imageUri) => {
    setIsLoading(true);
    setResult(null);

    // Simulação:
    // Em um app real, você enviaria a imageUri para uma API.
    // A API retornaria uma lista de tags/labels.
    // Aqui, vamos simular algumas respostas de API baseadas em uma lógica simples ou exemplos.
    // Como não podemos analisar a imagem no Snack, vamos apenas "adivinhar" algumas tags
    // ou ter um conjunto de tags de exemplo.

    // Exemplo de tags simuladas que a API poderia retornar:
    let simulatedApiTags = [];
    
    // Para demonstração, vamos usar um conjunto fixo de tags se uma imagem for selecionada.
    // Em um app mais avançado no Snack, você poderia ter botões "Simular imagem de garrafa", "Simular imagem de papel"
    // que definiriam essas `simulatedApiTags` antes de chamar a análise.
    // Por enquanto, vamos usar um exemplo genérico ou tentar uma lógica muito simples.
    if (imageUri) { // Apenas para indicar que estamos no fluxo da imagem
        // Vamos alternar entre alguns conjuntos de tags simuladas para demonstração
        const exampleSets = [
            ['garrafa', 'plástico', 'água', 'pet'], // Para "garrafa pet"
            ['lata', 'alumínio', 'refrigerante'], // Para "lata de refrigerante"
            ['papel', 'escritório', 'folha', 'branco'], // Para "papel de escritório"
            ['casca', 'banana', 'fruta', 'orgânico'], // Para "casca de banana"
            ['caixa', 'papelão', 'embalagem'] // Para "caixa de papelão"
        ];
        // Escolhe um conjunto aleatório para simular diferentes reconhecimentos
        simulatedApiTags = exampleSets[Math.floor(Math.random() * exampleSets.length)];
        console.log("Simulando API com as tags:", simulatedApiTags); // Para debug
    }


    setTimeout(() => {
      const foundItem = findItemByTags(simulatedApiTags);

      if (foundItem) {
        setResult(foundItem);
      } else {
        setResult({
          type: 'nao_reciclavel',
          name: 'Item não identificado pelas tags',
          instructions:
            'Não conseguimos identificar o item pela imagem. Tente digitar o nome ou uma foto mais clara de um ângulo diferente. Na dúvida, descarte como rejeito.',
          impact:
            'Descartar corretamente ajuda a proteger o meio ambiente.',
        });
      }
      setIsLoading(false);
    }, 2000); // Simula o tempo de resposta da API
  };

  // Função para lidar com a busca por texto (sem grandes alterações, mas pode se beneficiar da lógica de tags também)
  const handleTextSearch = () => {
    if (!itemName.trim()) {
      Alert.alert('Entrada Inválida', 'Por favor, digite o nome de um item.');
      return;
    }
    setSelectedImage(null);
    setIsLoading(true);
    setResult(null);

    setTimeout(() => {
      const searchName = itemName.toLowerCase().trim();
      // Tentamos encontrar por chave exata primeiro
      let foundItem = wasteData[searchName];

      // Se não encontrar por chave exata, tenta por palavras-chave (similar à busca por tags)
      if (!foundItem) {
          const searchTags = searchName.split(/\s+/); // Divide a string de busca em palavras/tags
          foundItem = findItemByTags(searchTags);
      }
      
      // Se ainda não encontrou, tenta uma busca parcial no nome do item
      if (!foundItem) {
        foundItem = Object.values(wasteData).find(
            (item) => item.name.toLowerCase().includes(searchName)
        );
      }


      if (foundItem) {
        setResult(foundItem);
      } else {
        setResult({
          type: 'nao_reciclavel',
          name: 'Item não encontrado',
          instructions:
            'Não encontramos este item em nossa base. Verifique a ortografia ou tente termos mais genéricos. Na dúvida, descarte como rejeito.',
          impact: 'Ajudar o planeta começa com pequenas ações.',
        });
      }
      setIsLoading(false);
    }, 1500);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://placehold.co/100x100/28a745/ffffff?text=COP30' }}
          style={styles.logo}
        />
        <Text style={styles.title}>Lixeira Inteligente COP30</Text>
      </View>

      <Text style={styles.instructionsText}>
        Tire uma foto do resíduo ou digite o nome para saber onde descartar:
      </Text>

      <View style={styles.inputSection}>
        <TouchableOpacity style={styles.button} onPress={pickImageAsync}>
          <Text style={styles.buttonText}>📷 Escolher da Galeria</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={takePhotoAsync}>
          <Text style={styles.buttonText}>📸 Tirar Foto</Text>
        </TouchableOpacity>

        {selectedImage && (
          <View style={styles.imagePreviewContainer}>
            <Image source={{ uri: selectedImage }} style={styles.imagePreview} />
            <TouchableOpacity onPress={() => {setSelectedImage(null); setResult(null); setItemName('');}} style={styles.removeImageButton}>
              <Text style={styles.removeImageButtonText}>X</Text>
            </TouchableOpacity>
          </View>
        )}

        <TextInput
          style={styles.input}
          placeholder="Ex: embalagem de iogurte, lata, etc."
          value={itemName}
          onChangeText={text => {
              setItemName(text);
              if (selectedImage) setSelectedImage(null); // Limpa imagem se começar a digitar
              if (result) setResult(null); // Limpa resultado anterior ao digitar
          }}
          onSubmitEditing={handleTextSearch}
        />
        <TouchableOpacity
          style={[styles.button, styles.searchButton]}
          onPress={handleTextSearch}
          disabled={isLoading || !itemName.trim() && !selectedImage}>
          <Text style={styles.buttonText}>
            {isLoading ? 'Buscando...' : '🔎 Identificar Resíduo'}
          </Text>
        </TouchableOpacity>
      </View>

      {isLoading && <Text style={styles.loadingText}>Analisando...</Text>}

      {result && !isLoading && (
        <View style={styles.resultSection}>
          <Text style={styles.resultTitle}>Resultado da Identificação:</Text>
          <View style={styles.resultCard}>
            <Text style={styles.binIcon}>{binIcons[result.type] || '❓'}</Text>
            <Text style={styles.resultItemName}>{result.name}</Text>
            <Text style={styles.resultLabel}>Instruções de Descarte:</Text>
            <Text style={styles.resultText}>{result.instructions}</Text>
            <Text style={styles.resultLabel}>Impacto Positivo:</Text>
            <Text style={styles.resultText}>{result.impact}</Text>
          </View>
        </View>
      )}
       <View style={styles.footer}>
        <Text style={styles.footerText}>
          Lixeira Inteligente COP30 - {new Date().getFullYear()}
        </Text>
      </View>
    </ScrollView>
  );
}

// --- Estilos (mantidos os mesmos do Passo 1, com pequenos ajustes se necessário) ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f7',
    paddingTop: Platform.OS === 'android' ? 25 : 0,
  },
  header: {
    alignItems: 'center',
    paddingVertical: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2c3e50',
    textAlign: 'center',
  },
  instructionsText: {
    fontSize: 16,
    color: '#34495e',
    textAlign: 'center',
    marginHorizontal: 20,
    marginVertical: 20,
  },
  inputSection: {
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  button: {
    backgroundColor: '#3498db',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '500',
  },
  input: {
    height: 50,
    borderColor: '#bdc3c7',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 10,
    fontSize: 16,
    backgroundColor: '#ecf0f1',
  },
  searchButton: { 
    backgroundColor: '#2ecc71',
  },
  imagePreviewContainer: {
    alignItems: 'center',
    marginVertical: 15,
    position: 'relative',
  },
  imagePreview: {
    width: 200,
    height: 200,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#3498db',
  },
  removeImageButton: {
    position: 'absolute',
    top: -10,
    right: Platform.OS === 'web' ? '30%' : 50,
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  removeImageButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  loadingText: {
    textAlign: 'center',
    fontSize: 18,
    color: '#e67e22',
    marginVertical: 20,
  },
  resultSection: {
    marginHorizontal: 20,
    marginBottom: 30,
  },
  resultTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultCard: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  binIcon: {
    fontSize: 60,
    marginBottom: 15,
  },
  resultItemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#3498db',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#7f8c8d',
    marginTop: 10,
    alignSelf: 'flex-start',
  },
  resultText: {
    fontSize: 15,
    color: '#34495e',
    marginBottom: 10,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
  footer: {
    padding: 20,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  footerText: {
    fontSize: 12,
    color: '#7f8c8d',
  },
});
